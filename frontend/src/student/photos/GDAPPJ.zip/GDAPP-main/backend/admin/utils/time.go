package jwt

import "time"

func GetCurrentTime() time.Time {
	return time.Now()
}